classdef abfile
%% abfile
%% Version 0.3 30-Jun-2008
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% a collection of routines for parsing hycom *.b files - and using the information
%% there to extract data in .a files
%%
%% The methods used to create and work with the abfile objects are as follows:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% abfile         -  used to create a ab file object
%%
%% Use these mehods to get info on what the file contains, what to send to retrieval routines
%%   getfieldnames  -  shows variables in file
%%   gettimes       -  shows time indices for file/variable
%%   getlevels      -  shows vertical level indices for file/variable
%%
%% Use these methods to retrieve data 
%%   getfield       -  retrieves fields, given time, vert. level and variable
%%   getpoint       -  retrieves point(s), given time, vert. level and variable
%% NB: Note that not all file types have vertical levels or times.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 
%% Example of usage:
%%   obj=abfile('F00restart2007_330_00.a','restart')  % creates file object
%%   getfieldnames(obj)                               % Lists variables in restart file
%%   getlevels    (obj,'u')                           % Lists vertical levels of variable u
%%   gettimes     (obj,'u')                           % Lists time indices of variable u
%%   fld=getfield(obj,'u',1,1 );        % retrieves variable u for time index 1
%%                                      % and vertical levels 1
%%   fld=getfield(obj,'u',1,[]);        % retrieves variable u for time index 1
%%                                      % and all vertical levels
%%   pnt=getpoint(obj,100,100,'u',[],1);% retrieves variable u for time index 1,
%%                                      % all vertical levels and grid point  100,100
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Available file types are 'restart', 'nersc_daily', 'nersc_weekly', 'relax' and others - 
%% see "help abfile.abfile" for more info. See for instance "help abfile.getfield" for more info 
%% on this method
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   properties (Hidden=true)
      fielddim  =[]; % Grid size
      header    =[];
      data      =[];
      base      =[];
      fields    =[]; % fields present in this file
      fieldk    =[]; % vertical levels present
      times     =[]; % vertical levels present
      iexpt     =[]; 
      iversn    =[]; 
      yrflg     =[]; 
      nstep     =[]; 
      dtime     =[]; 
      masklim   =[]; 
      avecount  =[]; 
      cline1    =[]; % Grid size
      cline2    =[]; % Grid size
      cline3    =[]; % Grid size
      cline4    =[]; % Grid size
      mapflg    =[]; % Grid size
      refyear   =[]; % Grid size
      ftype     = '';
   end %properties

   methods (Access='public') % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function fileobj = abfile(filename,ftype);
      %function fileobj = abfile(filename,ftype);
		% Constructor for the abfile class 
		%  - file name is the name of the .a file to open. 
		%  - ftype  is the file type to open. Allowed file types are 'restart' 
		%    'nersc_daily' , 'nersc_weekly' , 'nersc_daily' , 'relax' , 'archv'
		%    'forcing' , 'regional_grid' and 'raw'.

			fileobj.fielddim  = abfile.gridsize;
			fileobj.masklim   =1e28;

         if nargin~=2
            disp('**** Error: abfile must be called with two arguments - a file name, and type')
         else

            if (regexp(filename,'\.[ab]$'))
               datafile=filename;
					m = regexp(filename, '\.[ab]$');
               headerfile=[filename(1:m) 'b'];
               datafile=[filename(1:m) 'a'];
               filebase=filename(1:m-1);
            else
               headerfile='';
               datafile='';
            end
				fileobj.header=headerfile;
				fileobj.data  =datafile;
				fileobj.base  =filebase;
				fileobj.ftype =ftype;


            % Check if these files exist
            if ( isempty(dir(headerfile)) | isempty(dir(datafile)) )
               disp('**** Error: header and/or data file does not exist')
            end

				if (strcmp(ftype,'restart'))
					fileobj=loadrestartheader(fileobj);
				elseif (strcmp(ftype,'nersc_daily'))
					fileobj=loaddailyheader(fileobj);
				elseif (strcmp(ftype,'nersc_weekly'))
					fileobj=loadweeklyheader(fileobj);
				elseif (strcmp(ftype,'nersc_weekly'))
					fileobj=loadweeklyheader(fileobj);
				elseif (strcmp(ftype,'forcing'))
					fileobj=loadforcingheader(fileobj);
				elseif (strcmp(ftype,'regional_grid'))
					fileobj=loadrgheader(fileobj);
				elseif (strcmp(ftype,'relax'))
					fileobj=loadrelaxheader(fileobj);
				elseif (strcmp(ftype,'archv'))
					fileobj=loadarchvheader(fileobj);
				elseif (strcmp(ftype,'raw'))
               str=[];
               for k=1:10000
                   str = [str ; 'raw'];
               end 
               fileobj.fields=cellstr(str);
					fileobj.fieldk=1:10000; % Use what is normally vertical level as index
					fileobj.times=ones(1,10000);
				else 
					disp(['**** Error: unknown file type ' ftype ]);
				end
         end
      end  % function




      % Method returns times in data set
      function times = gettimes(hf,varname);
      % function times = gettimes(hf,varname);
		%   This returns the time indexes available in a .a - file. Use it
		%   if you need information on what you can plot. The following
		%   lists time indexes available for variable u in a restart file
		%
		%   obj=abfile('F00restart2007_330_00.a','restart', [400 320])  % creates file object
		%   gettimes     (obj,'u')                           % Lists time indices of variable u
         if (nargin==1)
            times=unique(hf.times);
         elseif (isempty(varname))
            times=unique(hf.times);
         else
            if (isvar(hf,varname))
               %Return "vertical" times stored for this variable
               I=find(strcmp(varname,hf.fields));
               times=unique(hf.times(I));
            else
               disp(['unknown variable ' varname]);
               times=[];
            end
         end
      end %function


      function levels = getlevels(hf,varname);
      % function times = getlevels(hf,varname);
		%   This returns the vertical levels available in a .a - file. Use it
		%   if you need information on what you can plot. The following
		%   lists vertical levels available for variable u in a restart file
		%
		%   obj=abfile('F00restart2007_330_00.a','restart', [400 320])  % creates file object
		%   getlevels    (obj,'u')            
         if (nargin==1)
            levels=unique(hf.fieldk);
         elseif (isempty(varname))
            levels=unique(hf.fieldk);
         else
            if (isvar(hf,varname))
               %Return "vertical" levels stored for this variable
               I=find(strcmp(varname,hf.fields));
               levels=unique(hf.fieldk(I));
            else
               disp(['unknown variable ' varname]);
               levels=[];
            end
         end
      end

      function fields=getfieldnames(hf) ;
      % function times = getfieldnames(hf);
		%   This returns the field names available in a .a - file. Use it
		%   if you need information on what you can plot. The following
		%   lists field names in a restart file
		%
		%   obj=abfile('F00restart2007_330_00.a','restart', [400 320])  % creates file object
		%   getfieldnames(obj)  
         fields=hf.fields;
         fields=unique(fields);
         fields=reshape(fields,prod(size(fields)),1);
      end


      %Char method for this class
      function s=char(hf)
         s=[ ];
         if (~isempty(hf.header))
         s2=sprintf('Header file is %s\n', hf.header );
            s=[ s s2 ];
         end
         if (~isempty(hf.data))
            s2= sprintf('Data   file is %s', hf.data  ) ;
            s=[ s s2 ];
         end
      end

      function display(hf)
         disp(char(hf));
      end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Retrieval methods                             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



      % Returns field values
      function field=getfield(hf,varname,layers,time)
      % function field=getfield(hf,varname,layers,time)
		% function returns variable for given layers and times
		% to see available fields/layers see the info methods
		% Note that not all files contain vertical levels, and not all 
		% files contain times.  Also note that it is possible  to set 
		% layers and time to empty fields to retrieve "everything
		%
		% %Example:
		%    obj=abfile('F00restart2007_330_00.a','restart', [400 320])  % creates file object
		%    fld=getfield(obj,'u',1,1);   % Retrieve variable u for layer and time index 1
		%    fld=getfield(obj,'u',[],1);  % Retrieve variable u for all layers and timeindex 1
		%    fld=getfield(obj,'u',1,[]);  % Retrieve variable u for all times and layer 1

         I=getindices(hf,varname,layers,time);
         if (isempty(I))
            field=[];
         else
            field=squeeze(load_a(hf,I));
				I=find(field>hf.masklim);
				field(I)=nan;

            if (strcmp(hf.ftype,'nersc_weekly'))
               if (prod(size(hf.getlevels(varname)))==prod(size(hf.getlevels('pres'))) & ~strcmp(varname,'pres'))
                  I2=getindices(hf,'pres',layers,time);
                  prs=squeeze(load_a(hf,I2));
                  field=field./max(prs,1.);
               else
                  field=field./hf.avecount;
               end
            end

         end
      end %function


      % Returns field values
      function point=getpoint(hf,ipiv,jpiv,varname,layers,time)
      %function point=getpoint(hf,ipiv,jpiv,varname,layers,time)
		% function returns variable for given layers and times in model points ipiv,jpiv
		% to see available fields/layers see the info methods
		% Note that not all files contain vertical levels, and not all 
		% files contain times.  Also note that it is possible  to set 
		% layers and time to empty fields to retrieve "everything
		%
		% %Example:
		%    obj=abfile('F00restart2007_330_00.a','restart', [400 320])  % creates file object
		%    fld=getpoint(obj,100,100,'u',1,1);   % Retrieve variable u for layer and time index 1
		%                                          % in point 100 100
		%    fld=getpoint(obj,100,100,'u',[],1);   % Retrieve variable u for all layers and time index 1
		%                                          % in point 100 100
		%    fld=getpoint(obj,[100 150],[100 200],'u',1,1);   % Retrieve variable u for all layers and time index 1
		%                                          % in points 100 100  and 150,200
         I=getindices(hf,varname,layers,time);
         if (isempty(I))
            point=[];
         else
            point=squeeze(loadpoint_a(hf,I,ipiv,jpiv));

            if (strcmp(hf.ftype,'nersc_weekly'))
               if (prod(size(hf.getlevels(varname)))==prod(size(hf.getlevels('pres'))) & ~strcmp(varname,'pres'))
                  I2=getindices(hf,'pres',layers,time);
                  prs=squeeze(loadpoint_a(hf,I2,ipiv,jpiv));
                  point=point./max(prs,1.);
               else
                  point=point./hf.avecount;
               end
            end
         end
      end

   end % methods
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Private   methods -- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   methods (Access='private')
    
      %Returns true if variable in header file
      function isvar = isvar(hf,varname);
         I=find(strcmp(hf.fields,varname));
         isvar=prod(size(I))>0;
      end

      % Method for getting indices in .b files from this object
      function indices=getindices(hf,varname,layers,time)
         if (~isempty(varname))
            if (~isvar(hf,varname))
               indices=[];
               return
            end
         end

         if (prod(size(layers))==2)
            layer1=layers(1);
            layer2=layers(2);
         elseif (prod(size(layers))==1)
            layer1=layers(1);
            layer2=layers(1);
         end
         indices=1:max(max( [ prod(size(hf.fields))  ...
                           prod(size(hf.fieldk))  ...
                           prod(size(hf.times ))  ...
                           ]));
         % Find indices into .a file
         if (~isempty(varname))
            I=find(strcmp(hf.fields,varname));
            indices=intersect(indices,I);
         end
         if (~isempty(layers))
            I=find(hf.fieldk>=layer1 & hf.fieldk <=layer2);
            indices=intersect(indices,I);
         end
         if (~isempty(time))
            I=find(hf.times==time);
            indices=intersect(indices,I);
         end
      end

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading field       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function fld=load_a(da,layerind_file);
      %function fld=load_a(filebase,layerind_file,idm,jdm);
         %disp(['Opening data file ' pakfile '.a' ]);
         % A quirk of the mod_za module, data is dumped containing a whole multiple of 4096 values.
         % This is used to skip to the correct record, but we will only read idm*jdm values...
         idm=da.fielddim(1);
         jdm=da.fielddim(2);
         n2drec=floor((idm*jdm+4095)/4096)*4096;
         bytes_per_float=4;

         % Skip to indices in layerind_file
         fid=fopen([da.base '.a'],'r','ieee-be'); % Big-endian
         fld=zeros(prod(size(layerind_file)),idm,jdm);
         for i=1:prod(size(layerind_file))
            %layerind_file(i)-1
            stat=fseek(fid,n2drec*bytes_per_float*(layerind_file(i)-1),'bof'); % Skip to corr record
            fldtmp=fread(fid,[idm jdm],'single');
            fld(i,:,:)=fldtmp;
         end
         fclose(fid);
      end

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading point of field %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% TODO: Extend to sets of points     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function fld=loadpoint_a(hf,layerind_file,ipiv,jpiv);
         % A quirk of the mod_za module, data is dumped containing a whole multiple of 4096 values.
         % This is used to skip to the correct record, but we will only read idm*jdm values...
         n2drec=floor((hf.fielddim(1)*hf.fielddim(2)+4095)/4096)*4096;
         bytes_per_float=4;


         % Skip to indices in layerind_file
         %layerind_file
         %disp([num2str(hf.fielddim(1)) ' ' num2str(hf.fielddim(2))])
         fld=zeros(prod(size(layerind_file)),prod(size(ipiv)));
         fid=fopen([hf.base '.a'],'r','ieee-be'); % Big-endian
         for i=1:size(fld,1)
         for j=1:size(fld,2)
            %disp([num2str(ipiv(j)) ' ' num2str(jpiv(j))])
            if (jpiv(j)>hf.fielddim(2) | ipiv(j)>hf.fielddim(1) |  ...
                ipiv(j)<1 | jpiv(j)<1 )
               disp('point is utside of grid')
               fld=[];
               return
            end
            %This is the point to read from the .a file - first index varies fastest
            pntskip=(jpiv(j)-1)*hf.fielddim(1) + (ipiv(j)-1);

            stat=fseek(fid,(n2drec*(layerind_file(i)-1) ...
               + pntskip)*bytes_per_float ,'bof'); % Skip to corr record
            fldtmp=fread(fid,1,'single');
            fld(i,j)=fldtmp;
         end
         end
         fclose(fid);
      end % function

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info of restart files %%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function df=loadrestartheader(olddf,filebase)
         df=olddf;
         fid=fopen([df.base '.b']);
         if (fid~=-1)

            A=fgetl(fid);
            i=findstr(A,'=')+1; %A(i:prod(size(A)))
            A=sscanf(A(i:prod(size(A))),'%d',3);
            df.iexpt=A(1);
            df.iversn=A(2);
            df.yrflg=A(3);

            A=fgetl(fid);
            i=findstr(A,'=')+1; %A(i:prod(size(A)))
            A=sscanf(A(i:prod(size(A))),'%d %f');
            df.nstep=A(1);
            df.dtime=A(2);
            while (1==1)
               

               A=fgetl(fid);
               if (A==-1) 
                  return
               end

               fldid=A(1:8);
               fldidtmp=fldid;
               fldid=strtrim(fldid);
               i=findstr(A,'=')+1;
               tst=sscanf(A(i:prod(size(A))),'%f');
               layer=tst(1);
               timeind=tst(2);
               bmin=tst(3);
               bmax=tst(4);

               df.fields=[ df.fields cellstr(fldid)];
               df.fieldk=[ df.fieldk layer];
               df.times =[ df.times timeind];
            end
            fclose(fid);
         end
      end %function



      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function da=loaddailyheader(oldda);
         da=oldda;
         fid=fopen([da.base '.b']);
         if (fid~=-1)
            for k=1:6
               A=fgetl(fid);
            end
            A=fgetl(fid); da.yrflg=sscanf(A,'%d');
            A=fgetl(fid); idm=sscanf(A,'%d');
            A=fgetl(fid); jdm=sscanf(A,'%d');
            A=fgetl(fid); kdm=sscanf(A,'%d');
            da.fielddim=[idm jdm kdm];
 

            for k=1:4
               A=fgetl(fid);
            end

            %AVE counter
            A=fgetl(fid); da.avecount=sscanf(A,'%d');

            for k=1:1001
               A=fgetl(fid);
            end

            match=0;
            while (1==1)
               A=fgetl(fid);
               if (A==-1)
                  return
               end

               fldid=strtrim(A(1:8));
               A=A(11:prod(size(A)));
               tst=sscanf(A,'%f');
               nstep=tst(1);
               dtime=tst(2);
               layer=tst(3);
               dens=tst(4);
               bmin=tst(5);
               bmax=tst(6);
               da.fields=[ da.fields cellstr(fldid) ];
               da.fieldk=[ da.fieldk layer ];
               da.times =[ da.times  1 ];
               da.nstep = nstep;
               da.dtime = dtime;
            end
            fclose(fid);
         else
            disp(['Error - could not read header file - I quit'])
            return
         end
      end % function

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading  weekly header info %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function dw=loadweeklyheader(olddw);
         dw=olddw;
         fid=fopen([dw.base '.b']);
         if (fid~=-1)


            dw.cline1=fgetl(fid);
            dw.cline2=fgetl(fid);
            dw.cline3=fgetl(fid);
            dw.cline4=fgetl(fid);

            A=fgetl(fid); dw.iversn=sscanf(A,'%d');
            A=fgetl(fid); dw.iexpt=sscanf(A,'%d');

            %Yearflag
            A=fgetl(fid); dw.yrflg=sscanf(A,'%d');

            %idm
            A=fgetl(fid); idm=sscanf(A,'%d');

            %jdm
            A=fgetl(fid); jdm=sscanf(A,'%d');

            %kdm
            A=fgetl(fid); kdm=sscanf(A,'%d');
            dw.fielddim=[idm jdm kdm];

            A=fgetl(fid);
            A=fgetl(fid);

            %AVE counter
            A=fgetl(fid); dw.avecount=sscanf(A,'%d');
            A=fgetl(fid);

            %Read until match
            while (1==1)
               

               A=fgetl(fid);
               if (A==-1) 
                  return
               end

               fldid=A(1:8);
               fldidtmp=fldid;
               fldid=strtrim(fldid);
               A=A(11:prod(size(A)));
               tst=sscanf(A,'%f');
               nstep=tst(1);
               dtime=tst(2);
               layer=tst(3);
               dens=tst(4);
               bmin=tst(5);
               bmax=tst(6);
               dw.fields=[dw.fields cellstr(fldid)];
               dw.fieldk=[dw.fieldk layer ];
               dw.times =[dw.times  1 ];
            end
         end
      end % function

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function frc=loadforcingheader(oldfrc);
         frc=oldfrc;
         fid=fopen([frc.base '.b']);
         if (fid~=-1)

            % First two lines are usually somee file info
            frc.cline1=fgetl(fid);
            fileinfo2=fgetl(fid);
            fileinfo3=fgetl(fid);
            fileinfo4=fgetl(fid);

            % next line is horizontal grid size
            A=fgetl(fid);
            ind=regexp(A,'=');
            %A(ind+1:end)
            B=sscanf(A(ind+1:end),'%d');
            idm=B(1) ; jdm=B(2);
            frc.fielddim=[idm jdm];
				frc.refyear   =1901; % Year flag

            % Next lines are indexes into .a file
            while (1==1)

               A=fgetl(fid);
               if (A==-1)
                  return
               end

               ind=regexp(A,':');
               fldid=A(1:ind);
               fldid=strtrim(fldid);
               ind=regexp(fldid,'\(.*\)');
               fldid=fldid(1:ind-1);
               ind=regexp(A,'=');
               B=sscanf(A(ind+1:end),'%f');
               fldtime=B(1);
               fldtime=datenum(frc.refyear,1,1)+fldtime;
               frc.fields=[ frc.fields cellstr(fldid)];
               frc.times =[ frc.times  fldtime ];
               frc.fieldk=[ frc.fieldk 1       ];
            end

            fclose(fid);
         else
            disp(['Error - could not read header file ' frc.base '.b - I quit'])
            return
         end
      end

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info for regional.grid.ab %%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function rg=loadrgheader(oldrg);
         rg=oldrg;
         fid=fopen([rg.base '.b']);
         if (fid~=-1)

            % next line is horizontal grid size
            A=fgetl(fid); idm=sscanf(A,'%d',1);
            A=fgetl(fid); jdm=sscanf(A,'%d',1);
            A=fgetl(fid); rg.mapflg=sscanf(A,'%d',1);
            rg.fielddim=[idm jdm];

            % Next lines are indexes into .a file
            while (1==1)
               A=fgetl(fid);
               if (A==-1)
                  return
               end
               ind=regexp(A,':');
               fldid=A(1:ind-1);
               fldid=strtrim(fldid);
               rg.fields=[ rg.fields cellstr(fldid)];
               rg.fieldk=[ rg.fieldk 1];
               rg.times =[ rg.times  1];
            end
            fclose(fid);
         else
            disp(['Error - could not read header file ' rg.base '.b - I quit'])
            return
         end
      end %function

      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info of relax files %%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function rlx=loadrelaxheader(oldrlx)
         rlx=oldrlx;
         fid=fopen([rlx.base '.b']);
         if (fid~=-1)

            rlx.cline1=fgetl(fid);
            rlx.cline2=fgetl(fid);
            rlx.cline3=fgetl(fid);
            rlx.cline4=fgetl(fid);
            A=fgetl(fid);
            i=findstr(A,'=')+1; %A(i:prod(size(A)))
            A=sscanf(A(i:prod(size(A))),'%d',2);
            rlx.fielddim=[A(1) A(2)];

            while (1==1)
               

               A=fgetl(fid);
               if (A==-1) 
                  return
               end

               i=findstr(A,':');
               fldid=A(1:i-1);
               fldid=strtrim(fldid);

               i=findstr(A,'=')+1;
               tst=sscanf(A(i:prod(size(A))),'%d');
               timeind=tst(1);
               layer=tst(2);

               rlx.fields=[ rlx.fields cellstr(fldid)];
               rlx.fieldk=[ rlx.fieldk layer];
               rlx.times =[ rlx.times timeind];
            end
            fclose(fid);
         end
      end %function



      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%% Routine for reading header info %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      function archv=loadarchvheader(oldarchv)
         archv=oldarchv;
         fid=fopen([archv.base '.b']);
         if (fid~=-1)

            archv.cline1=fgetl(fid);
            archv.cline2=fgetl(fid);
            archv.cline3=fgetl(fid);
            fgetl(fid);
            A=fgetl(fid); archv.iversn=sscanf(A,'%d',1);
            A=fgetl(fid); archv.iexpt =sscanf(A,'%d',1);
            A=fgetl(fid); archv.yrflg =sscanf(A,'%d',1);
            A=fgetl(fid); idm         =sscanf(A,'%d',1);
            A=fgetl(fid); jdm         =sscanf(A,'%d',1);
            archv.fielddim=[idm jdm];
            fgetl(fid);


            while (1==1)


               A=fgetl(fid);
               if (A==-1)
                  return
               end

               fldid=A(1:8);
               fldidtmp=fldid;
               fldid=strtrim(fldid);
               i=findstr(A,'=')+1;
               tst=sscanf(A(i:prod(size(A))),'%d %f %d %f %f');
               layer=tst(3);
               %timeind=tst(2)
               %bmin=tst(3)
               %bmax=tst(4)
               archv.fields=[ archv.fields cellstr(fldid)];
               archv.fieldk=[ archv.fieldk layer];
               archv.times =[ archv.times  1 ];

            end
            fclose(fid);
         end
      end % function


   end %method

   methods (Static=true , Access='private') % 
	   function gridsize=gridsize();
	   %function gridsize=gridsize();
		%Opens regional.grid.b to get grid dimension
         fid=fopen(['regional.grid.b']);
         if (fid~=-1)
            A=fgetl(fid); A=sscanf(A,'%d',1); idm=A(1);
            A=fgetl(fid); A=sscanf(A,'%d',1); jdm=A(1);
				fclose(fid);
				gridsize=[idm jdm];
			else
				gridsize=[];
			end
		end %function
	end %methods
end %classdef
